let FPS = 60;

export function getFPS() {
  return FPS;
}

export function setFPS(value) {
  FPS = value;
}
